<?php
$PLUS=array (
  'HideVideo' => 
  array (
    'off' => '',
    'data' => 
    array (
      0 => '567897',
    ),
    'info' => '应版权方要求此视频已下架，请支持正版！',
  ),
  'JmpVideo' => 
  array (
    'off' => '',
    'data' => 
    array (
      2204266 => '1234',
    ),
  ),
  'Other' => 
  array (
    'numPerPage' => '20',
  ),
);
